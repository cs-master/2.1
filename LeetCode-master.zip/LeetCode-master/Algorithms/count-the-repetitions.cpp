// 466. Count The Repetitions
// https://leetcode.com/problems/count-the-repetitions/
#include <iostream>
#include <cassert>
#include <cstring>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iterator>
using namespace std;

class Solution {
public:
	int getMaxRepetitions(string s1, int n1, string s2, int n2) {
		if (s1.empty() || n1 <= 0 || s2.empty() || n2 <= 0) {
			return 0;
		}
		const size_t S1_size = s1.size() * size_t(n1);
		const size_t S2_size = s2.size() * size_t(n2);
		if (S1_size < S2_size) {
			return 0;
		}
		unordered_map<char, vector<size_t>> dic_s1;
		for (size_t i = 0; i < s1.size(); i++) {
			const char ch = s1.at(i);
			dic_s1[ch].push_back(i);
		}
		for (size_t i = 0; i < s2.size(); i++) {
			const char ch = s2.at(i);
			if (!dic_s1.count(ch)) {
				return 0;
			}
		}
		if (dic_s1.size() == 1) {
			return S1_size / S2_size;
		}
		size_t OPT[100];
		memset(OPT, 0, sizeof(OPT));
		for (size_t i = 0; i < s1.size(); i++) {
			size_t j = i;
			for (size_t k = 0; k < s2.size(); k++) {
				const char ch = s2.at(k);
				const vector<size_t> &dic_s1_vec = dic_s1.at(ch);
				const size_t a = dic_s1_vec.front();
				const size_t b = dic_s1_vec.back();
				const size_t d = s1.size();
				if (k == 0) {
					if (j <= b) {
						j = *lower_bound(begin(dic_s1_vec), end(dic_s1_vec), j);
					}
					else {
						const size_t k = (j - b) % d ? (j - b) / d + 1 : (j - b) / d;
						if (j <= a + k * d) {
							j = a + k * d;
						}
						else {
							j = *lower_bound(begin(dic_s1_vec), end(dic_s1_vec), j - k * d) + k * d;
						}
					}
				}
				else if (j < b) {
					j = *upper_bound(begin(dic_s1_vec), end(dic_s1_vec), j);
				}
				else {
					const size_t k = (j + 1 - b) % d ? (j + 1 - b) / d + 1 : (j + 1 - b) / d;
					if (j < a + k * d) {
						j = a + k * d;
					}
					else {
						j = *upper_bound(begin(dic_s1_vec), end(dic_s1_vec), j - k * d) + k * d;
					}
				}
			}
			OPT[i] = j + 1 - i;
		}
		size_t j = 0;
		for (size_t i = 0; i <= S1_size; j++) {
			const size_t idx = i % s1.size();
			i += OPT[idx];
		}
		return (j - 1) / n2;
	}
};

// BEGIN: Time Limit Exceeded
// class Solution {
// public:
// 	int getMaxRepetitions(string s1, int n1, string s2, int n2) {
// 		if (s1.empty() || n1 <= 0 || s2.empty() || n2 <= 0) {
// 			return 0;
// 		}
// 		const size_t S1_size = s1.size() * size_t(n1);
// 		const size_t S2_size = s2.size() * size_t(n2);
// 		if (S1_size < S2_size) {
// 			return 0;
// 		}
// 		unordered_map<char, vector<size_t>> dic_s1;
// 		for (size_t i = 0; i < s1.size(); i++) {
// 			const char ch = s1.at(i);
// 			dic_s1[ch].push_back(i);
// 		}
// 		for (size_t i = 0; i < s2.size(); i++) {
// 			const char ch = s2.at(i);
// 			if (!dic_s1.count(ch)) {
// 				return 0;
// 			}
// 		}
// 		if (dic_s1.size() == 1) {
// 			return S1_size / S2_size;
// 		}
// 		size_t i = 0, j = 0;
// 		for (i = 0, j = 0; i < S1_size; j++) {
// 			if (i > 0 and i % s1.size() == 0 and j > 0 and j % s2.size() == 0) {
// 				const size_t k = S1_size / i;
// 				i += (k - 1) * i;
// 				j += (k - 1) * j;
// 			}
// 			if (i < S1_size) {
// 				const size_t jdx = j % s2.size();
// 				const char jch = s2.at(jdx);
// 				vector<size_t>& dic_s1_vec = dic_s1.at(jch);
// 				if (j == 0) {
// 					i = dic_s1_vec.front();
// 					continue;
// 				}
// 				if (j > 0) {
// 					if (dic_s1_vec.back() <= i) {
// 						const size_t dic_s1_vec_back = dic_s1_vec.back();
// 						const size_t k = (i + 1 - dic_s1_vec_back) % s1.size() ? (i + 1 - dic_s1_vec_back) / s1.size() + 1 : (i + 1 - dic_s1_vec_back) / s1.size();
// 						if (i < dic_s1_vec.front() + k * s1.size()) {
// 							i = dic_s1_vec.front() + k * s1.size();
// 						}
// 						else {
// 							const vector<size_t>::iterator it = upper_bound(begin(dic_s1_vec), end(dic_s1_vec), i - k * s1.size());
// 							i = *it + k * s1.size();
// 						}
// 					}
// 					else {
// 						const vector<size_t>::iterator it = upper_bound(begin(dic_s1_vec), end(dic_s1_vec), i);
// 						i = *it;
// 					}
// 					continue;
// 				}
// 			}
// 		}
// 		return (j - 1) / S2_size;
// 	}
// };
// END: Time Limit Exceeded

// BEGIN: Time Limit Exceeded
// class Solution {
// public:
// 	int getMaxRepetitions(string s1, int n1, string s2, int n2) {
// 		if (s1.empty() || n1 <= 0 || s2.empty() || n2 <= 0) {
// 			return 0;
// 		}
// 		unordered_map<char, list<size_t>> dic_s1;
// 		for (size_t i = 0; i < s1.size(); i++) {
// 			const char ch = s1.at(i);
// 			dic_s1[ch].push_back(i);
// 		}
// 		for (size_t i = 0; i < s2.size(); i++) {
// 			const char ch = s2.at(i);
// 			if (!dic_s1.count(ch)) {
// 				return 0;
// 			}
// 		}
// 		const size_t S1_size = s1.size() * size_t(n1);
// 		const size_t S2_size = s2.size() * size_t(n2);
// 		size_t i = 0, j = 0;
// 		for (i = 0, j = 0; i < S1_size; j++) {
// 			const size_t jdx = j % s2.size();
// 			const char jch = s2.at(jdx);
// 			list<size_t> &dic_s1_list = dic_s1.at(jch);
// 			if (j == 0) {
// 				i = dic_s1_list.front();
// 				dic_s1_list.pop_front();
// 				dic_s1_list.push_back(i + s1.size());
// 				continue;
// 			}
// 			if (j > 0) {
// 				while (dic_s1_list.front() <= i) {
// 					dic_s1_list.push_back(dic_s1_list.front() + s1.size());
// 					dic_s1_list.pop_front();
// 				}
// 				i = dic_s1_list.front();
// 				dic_s1_list.push_back(i + s1.size());
// 				dic_s1_list.pop_front();
// 				continue;
// 			}
// 		}
// 		return (j - 1) / S2_size;
// 	}
// };
// END: Time Limit Exceeded

// BEGIN: Time Limit Exceeded
// class Solution {
// public:
// 	int getMaxRepetitions(string s1, int n1, string s2, int n2) {
// 		if (s1.empty() || n1 <= 0 || s2.empty() || n2 <= 0) {
// 			return 0;
// 		}
// 		unordered_map<char, vector<size_t>> dic_s1;
// 		for (size_t i = 0; i < s1.size(); i++) {
// 			const char ch = s1.at(i);
// 			dic_s1[ch].push_back(i);
// 		}
// 		for (size_t i = 0; i < s2.size(); i++) {
// 			const char ch = s2.at(i);
// 			if (!dic_s1.count(ch)) {
// 				return 0;
// 			}
// 		}
// 		const size_t S1_size = s1.size() * size_t(n1);
// 		const size_t S2_size = s2.size() * size_t(n2);
// 		size_t i = 0, j = 0;
// 		for (i = 0, j = 0; i < S1_size; j++) {
// 			const size_t jdx = j % s2.size();
// 			const char jch = s2.at(jdx);
// 			vector<size_t>& dic_s1_vec = dic_s1.at(jch);
// 			if (j == 0) {
// 				vector<size_t>::iterator it = begin(dic_s1_vec);
// 				i = *it;
// 				dic_s1_vec.erase(it);
// 				dic_s1_vec.push_back(i + s1.size());
// 				continue;
// 			}
// 			if (j > 0) {
// 				vector<size_t>::iterator it = upper_bound(begin(dic_s1_vec), end(dic_s1_vec), i);
// 				while (it == end(dic_s1_vec)) {
// 					vector<size_t> tmp;
// 					for (const auto &k : dic_s1_vec) {
// 						tmp.push_back(k + s1.size());
// 					}
// 					dic_s1_vec.clear();
// 					dic_s1_vec = tmp;
// 					it = upper_bound(begin(dic_s1_vec), end(dic_s1_vec), i);
// 				}
// 				i = *it;
// 				vector<size_t> tmp;
// 				for (vector<size_t>::iterator jt = begin(dic_s1_vec); jt != next(it); jt++) {
// 					tmp.push_back(*jt + s1.size());
// 				}
// 				dic_s1_vec.erase(begin(dic_s1_vec), next(it));
// 				dic_s1_vec.insert(end(dic_s1_vec), begin(tmp), end(tmp));
// 				continue;
// 			}
// 		}
// 		return (j - 1) / S2_size;
// 	}
// };
// END: Time Limit Exceeded

// BEGIN: Time Limit Exceeded
// class Solution {
// public:
// 	int getMaxRepetitions(string s1, int n1, string s2, int n2) {
// 		if (s1.empty() || n1 <= 0 || s2.empty() || n2 <= 0) {
// 			return 0;
// 		}
// 		unordered_map<char, set<size_t>> dic_s1;
// 		for (size_t i = 0; i < s1.size(); i++) {
// 			const char ch = s1.at(i);
// 			dic_s1[ch].insert(i);
// 		}
// 		for (size_t i = 0; i < s2.size(); i++) {
// 			const char ch = s2.at(i);
// 			if (!dic_s1.count(ch)) {
// 				return 0;
// 			}
// 		}
// 		const size_t S1_size = s1.size() * size_t(n1);
// 		const size_t S2_size = s2.size() * size_t(n2);
// 		size_t i = 0;
// 		size_t j = 0;
// 		for (i = 0, j = 0; i < S1_size; j++) {
// 			const size_t jdx = j % s2.size();
// 			const char jch = s2.at(jdx);
// 			set<size_t>& dic_s1_set = dic_s1.at(jch);
// 			if (j == 0) {
// 				i = *begin(dic_s1_set);
// 				dic_s1_set.erase(begin(dic_s1_set));
// 				dic_s1_set.insert(i + s1.size());
// 				continue;
// 			}
// 			if (j > 0) {
// 				set<size_t>::iterator it = dic_s1_set.upper_bound(i);
// 				while (it == end(dic_s1_set)) {
// 					vector<size_t> tmp;
// 					for (const auto &k : dic_s1_set) {
// 						tmp.push_back(k + s1.size());
// 					}
// 					dic_s1_set.clear();
// 					dic_s1_set.insert(begin(tmp), end(tmp));
// 					it = dic_s1_set.upper_bound(i);
// 				}
// 				i = *it;
// 				vector<size_t> tmp(begin(dic_s1_set), next(it));
// 				dic_s1_set.erase(begin(dic_s1_set), next(it));
// 				for (const auto&k : tmp) {
// 					dic_s1_set.insert(k + s1.size());
// 				}
// 				continue;
// 			}
// 		}
// 		return (j - 1) / S2_size;
// 	}
// };
// END: Time Limit Exceeded

int main(void) {
	Solution solution;
	string s1;
	int n1 = 0;
	string s2;
	int n2 = 0;
	int result = 0;
	int answer = 0;

	s1 = "aahumeaylnlfdxfircvscxggbwkfnqduxwfnfozvsrtkjprepggxrpnrvystmwcysyycqpevikeffmznimkkasvwsrenazkycxf";
	n1 = 1000000;
	s2 = "aac";
	n2 = 10;
	answer = 200000;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	s1 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
	n1 = 1000000;
	s2 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
	n2 = 103;
	answer = 5620;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	s1 = "lovelive";
	n1 = 10;
	s2 = "lovelive";
	n2 = 10;
	answer = 1;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	s1 = "phqghumeaylnlfdxfircvscxggbwkfnqduxwfnfozvsrtkjprepggxrpnrvystmwcysyycqpevikeffmznimkkasvwsrenzkycxf";
	n1 = 100;
	s2 = "xtlsgypsfa";
	n2 = 1;
	answer = 49;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	s1 = "abc";
	n1 = 1;
	s2 = "abc";
	n2 = 1;
	answer = 1;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	s1 = "phqghumeaylnlfdxfircvscxggbwkfnqduxwfnfozvsrtkjpre";
	n1 = 1000000;
	s2 = "pggxr";
	n2 = 100;
	answer = 10000;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	s1 = "acb";
	n1 = 4;
	s2 = "ab";
	n2 = 2;
	answer = 2;
	result = solution.getMaxRepetitions(s1, n1, s2, n2);
	assert(answer == result);

	cout << "\nPassed All\n";
	return 0;
}